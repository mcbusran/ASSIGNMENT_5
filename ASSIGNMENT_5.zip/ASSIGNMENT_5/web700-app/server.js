const express = require("express");
const path = require("path");
const collegeData = require("C:/WEB700_OTHERS/ASSIGNMENT_5/web700-app/modules/collegeData");
const exphbs = require('express-handlebars');

const app = express();
const HTTP_PORT = process.env.PORT || 8089;

// Create an instance of Handlebars engine
const hbs = exphbs.create({
    extname: ".hbs",
    defaultLayout: "main",
    helpers: {
        equal: function (val1, val2, options) {
            return val1 === val2 ? options.fn(this) : options.inverse(this);
        },
        navLink: function(url, options) {
            return '<li' + (url === app.locals.activeRoute ? ' class="nav-item active" ' : ' class="nav-item" ') +
                '><a class="nav-link" href="' + url + '">' + options.fn(this) + '</a></li>';
        }
    }
});

// Set the view engine to the created Handlebars instance
app.engine("hbs", hbs.engine);
app.set("view engine", "hbs");

// Middleware to parse URL-encoded bodies
app.use(express.urlencoded({ extended: true }));

// Middleware to serve static files
app.use(express.static(path.join(__dirname, "public")));

// Middleware to set active route
app.use(function(req, res, next) {
    let route = req.path.substring(1);
    app.locals.activeRoute = "/" + (isNaN(route.split('/')[1]) ? route.replace(/\/(?!.*)/, "") : route.replace(/\/(.*)/, ""));
    next();
});

// Route to handle root URL and render "home" view
app.get("/", (req, res) => {
    res.render("home");
});

// Route to handle /students page
app.get("/students", (req, res) => {
    const students = [
        { studentNum: "12345", firstName: "John", lastName: "Doe", program: "Computer Science" },
        { studentNum: "67890", firstName: "Jane", lastName: "Smith", program: "Business Administration" },
        { studentNum: "13579", firstName: "Bob", lastName: "Johnson", program: "Engineering" },
        // Add more student objects here...
    ];
    res.render("students", { students: students });
});

// Route to handle /courses page
app.get("/courses", (req, res) => {
    const courses = [
        { code: "COURSE101", name: "Introduction to Web Development", credits: 3 },
        { code: "COURSE201", name: "Advanced Web Programming", credits: 4 },
        { code: "COURSE301", name: "Database Design and Implementation", credits: 3 },
        // Add more course objects here...
    ];
    res.render("courses", { courses: courses });
});

// Route to handle /about page
app.get("/about", (req, res) => {
    res.render("about");
});

// Route to handle HTML demo page
app.get("/htmlDemo", (req, res) => {
    res.render("htmlDemo");
});

// Route to handle /students/add view
app.get("/addStudent", (req, res) => {
    res.render("addStudent");
});

// Route to handle form submission for adding a student (Step 5)
app.post("/addStudent", (req, res) => {
    const studentData = req.body;
    collegeData.addStudent(studentData)
        .then(() => {
            res.redirect("/students");
        })
        .catch((error) => {
            console.error("Error adding student:", error);
            res.status(500).send("Error adding student");
        });
});

// Route to handle /tas view
app.get("/tas", (req, res) => {
    collegeData.getTAs()
        .then((tas) => {
            res.render("tas", { tas: tas });
        })
        .catch(() => {
            res.status(404).json({ message: "No results returned" });
        });
});

// Route to handle unmatched routes
app.use((req, res) => {
    res.status(404).send("Page Not Found");
});

// Initialize collegeData and start the server
collegeData
    .initialize()
    .then(() => {
        app.listen(HTTP_PORT, onHttpStart);
    })
    .catch((err) => {
        console.error("Error initializing collegeData:", err);
    });

// Function to execute after the HTTP server starts listening for requests
function onHttpStart() {
    console.log("Express http server listening on: " + HTTP_PORT);
}
